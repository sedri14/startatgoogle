package Enums;

public class Main {
    public static void main(String[] args) {

        Bird houseSparrow = Bird.HOUSE_SPARROW;
        houseSparrow.sing();
        Bird indigoBunting = Bird.INDIGO_BUNTING;
        indigoBunting.sing();

    }
}
